package cpm.automation.jsonschema;
import static org.hamcrest.MatcherAssert.assertThat;

import org.testng.annotations.Test;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import io.restassured.RestAssured;

public class JsonScheam {

@Test	
	public void JsonSchemachecking() {
		
		RestAssured.baseURI="https://dummy.restapiexample.com/api/v1/create";
		String rsp= RestAssured.given()
		.when().post().getBody().asString();
		assertThat(rsp,matchesJsonSchemaInClasspath("expectedjsonschema.json"));
	}
	
}
