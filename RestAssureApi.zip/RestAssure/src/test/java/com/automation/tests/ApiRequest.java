package com.automation.tests;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import net.minidev.json.JSONObject;

@Test
public class ApiRequest {
	
	public void GetRequest() {
		
		RestAssured
		.given().contentType(ContentType.JSON)
		.baseUri("https://dummy.restapiexample.com/api/v1/employee/2")
		.when()
		.get()
		.then()
		.assertThat()
		.body("status", Matchers.equalTo("success"))
		.body("data.employee_name", Matchers.equalTo("Garrett Winters"));
		
	
	
}
public void PostRequest() {
		
		JSONObject Emp = new JSONObject();
		
		Emp.put("name", "Mahesh");
		Emp.put("job", "The Greate QA");
		
		RestAssured.given().contentType(ContentType.JSON)
		.body(Emp.toString())
		.baseUri("https://reqres.in/api/users")
		//.log().body()
		.when()
		.post()
		.then()
		.assertThat()
		//.log().body()
		.statusCode(201)
		.body("name", Matchers.equalTo("Mahesh"))
		.body("job", Matchers.equalTo("The Greate QA"));
		
	}
	public void PutRequest() {
JSONObject Emp = new JSONObject();
		
		Emp.put("name", "Master Mahesh");
		Emp.put("job", "The Greate QA");
		
		RestAssured.given().contentType(ContentType.JSON)
		.body(Emp.toString())
		.baseUri("https://reqres.in/api/users/2")
		//.log().body()
		.when()
		.put()
		.then()
		.assertThat()
		//.log().body()
		.statusCode(200)
		.body("name", Matchers.equalTo("Master Mahesh"))
		.body("job", Matchers.equalTo("The Greate QA"));
		
	}
	
	public void DeleteRequest() {
		
		RestAssured.given().baseUri("https://reqres.in/api/users/2")
		.when()
		.delete()
		.then()
		.statusCode(204);
	}
	
}
